<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Employee;
class EmployeeapiController extends Controller
{
    function list ($id=null)
    {
        return $id?Employee::find($id):Employee::all();
    }
    function add(Request $req)
    {
        $employee = new Employee;
        $employee->name=$req->name;
        $employee->email=$req->email;
        $employee->phone_no=$req->phone_no;
        $employee->message=$req->message;
        $result=$employee->save();
        if($result)
        {
            return ["result"=>"Data hasbeen saved"];
            // return ["result"=>"done"];
        }
        else
        {
            return ["result"=>"Operation failed"];
        }
    }
    function update(Request $req)
    {
        $employee = Employee::find($req->id);
        $employee->name=$req->name; 
        $employee->email=$req->email;
        $employee->phone_no=$req->phone_no;
        $employee->message=$req->message;
        $result=$employee->save();
        if($result)
        {
            return ["result"=>"Data hasbeen updated"];
            // return ["result"=>"done"];
        }
        else
        {
            return ["result"=>"Operation failed"];
        }
    }

    function delete($id)
    {
        $employee = Employee::find($id);
        $result=$employee->delete();
        if($result)
        {
            return ["result"=>"Data hasbeen deleteed"];
            // return ["result"=>"done"];
        }
        else
        {
            return ["result"=>"Operation failed"];
        }
    }
}
