<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\InfoRequest;

class CustomValidationController extends Controller
{
    public function show() 
    {
        return view('test.custom-validation');
    }

    public function perform(InfoRequest $request) 
    {
        // Save after validated
    }
}