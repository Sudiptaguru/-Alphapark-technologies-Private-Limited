
    <div class="bg-light p-5 rounded">
        <h1>Laravel Custom Validation Rule by CodeAndDeploy.com</h1>
        
        <form method="post" action="{{ route('custom-validation') }}">
            <input type="hidden" name="_token" value="{{ csrf_token() }}" />

            <div class="form-group form-floating mb-3">
                
                <div class="form-group">
                    <label>Full name</label>
                    <input type="text" 
                        name="name" 
                        placeholder="Name" 
                        class="form-control" 
                        value="{{ old('name') }}">
                    @if ($errors->has('name'))
                        <span class="text-danger text-left">{{ $errors->first('name') }}</span>
                    @endif
                </div>

                <div class="form-group mt-3">
                    <label>Birth Year</label>
                    <input type="number" 
                        name="birth_year" 
                        placeholder="E.g. 1990" 
                        class="form-control"
                        value="{{ old('birth_year') }}"
                        maxlength="4">
                    @if ($errors->has('birth_year'))
                        <span class="text-danger text-left">{{ $errors->first('birth_year') }}</span>
                    @endif
                </div>

            </div>

            <button class="w-100 btn btn-lg btn-primary" type="submit">Save</button>
        </form>
    </div>