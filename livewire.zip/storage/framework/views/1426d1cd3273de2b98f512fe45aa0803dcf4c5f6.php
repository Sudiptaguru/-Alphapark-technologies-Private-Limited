<!DOCTYPE html>
<html>
<head>
    <title>Laravel Livewire CRUD</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h2>Laravel Livewire CRUD</h2>
                    </div>
                    <div class="card-body">
                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('message')); ?>

                            </div>
                        <?php endif; ?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('posts')->html();
} elseif ($_instance->childHasBeenRendered('FJGZbTJ')) {
    $componentId = $_instance->getRenderedChildComponentId('FJGZbTJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('FJGZbTJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FJGZbTJ');
} else {
    $response = \Livewire\Livewire::mount('posts');
    $html = $response->html();
    $_instance->logRenderedChild('FJGZbTJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html><?php /**PATH C:\Users\Sudipta Guru\Desktop\laravel\livewire\resources\views/welcome.blade.php ENDPATH**/ ?>