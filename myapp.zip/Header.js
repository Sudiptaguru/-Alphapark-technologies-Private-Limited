// import Container from "react-bootstrap/Container";
// import Nav from "react-bootstrap/Nav";
// import Navbar from "react-bootstrap/Navbar";
import { Link } from "react-router-dom";
function Header() {
  return (
    <div>
      <>
        <div class="topnav">
          <Link class="active" to="#home">
            Home
          </Link>
          <Link to="employee">About</Link>
          <Link to="#">Contact</Link>
          <div class="login-container">
            <Link to="login">Login</Link>
            <Link to="register">Register</Link>
          </div>
        </div>
      </>
    </div>
  );
}
export default Header;
