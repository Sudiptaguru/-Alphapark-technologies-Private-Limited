/* eslint-disable no-template-curly-in-string */
import React from "react";
import "./App.css";
import Header from "./Header";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Employee from "./Employee";
import Addemployee from "./Addemployee";
import Login from "./Login";
import Register from "./Register";
function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Header />
        <h1 className="heading">Ecom Project</h1>
        <Routes>
          <Route path="employee" element={<Employee />} />
          <Route path="/edit-employee/:id" element={<Employee />} />
          <Route path="add-employee" element={<Addemployee />} />
          <Route path="login" element={<Login />} />
          <Route path="register" element={<Register />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
