import React, { Component } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
class Addemployee extends Component {
    state = {
        name: '',
        email: '',
        phone_no: '',
        message: '',
    }
    handleInput = async (e) => {
        this.setState({
            [e.target.name]: e.target.value
        });
    }
    saveStudent = async (e) => {
        e.preventDefault();
        const res = await axios.post('http://localhost/example-app/public/api/add', this.state);
        if(res.data.status === 200)
        {
            console.log(res.data.message);
            this.setState({
                name: '',
                email: '',
                phone_no: '',
                message: '',
            });
        }
    }
  render() {
    return (
      <din className="container">
        <div className="row">
          <div className="col-md-12">
            <div className="card">
              <div className="card-header">
                <h4>
                  Add students
                  <Link to="/" className="btn btn-primary btn-sm float-end">
                    Back
                  </Link>
                </h4>
              </div>
              <div className="card-body">
                <form onSubmit={this.saveStudent}>
                  <div className="form-group mb-3">
                    <label for="">Name</label>
                    <input
                      type="text"
                      name="name"
                      onChange={this.handleInput}
                      value={this.state.name}
                      className="form-control"
                    />
                  </div>
                  <div className="form-group mb-3">
                    <label for="">Email</label>
                    <input
                      type="text"
                      name="email"
                      onChange={this.handleInput}
                      value={this.state.email}
                      className="form-control"
                    />
                  </div>
                  <div className="form-group mb-3">
                    <label for="">Phone No</label>
                    <input
                      type="text"
                      name="phone_no"
                      onChange={this.handleInput}
                      value={this.state.phone_no}
                      className="form-control"
                    />
                  </div>
                  <div className="form-group mb-3">
                    <label for="">Message</label>
                    <input
                      type="text"
                      className="form-control"
                      name="message"
                      onChange={this.handleInput}
                      value={this.state.message}
                      placeholder="Message"
                    />
                  </div>
                  <div className="form-group mb-3">
                    <button type="submit" className="btn btn-primary">
                      Save Student
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </din>
    );
  }
}
export default Addemployee;
