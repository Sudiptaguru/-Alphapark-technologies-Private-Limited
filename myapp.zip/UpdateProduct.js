function UpdateProduct()
{
    return(
        <div>
            <h1>UpdateProduct Page</h1>
        </div>
    )
}
export default UpdateProduct